package Project;

import java.util.ArrayList;
import java.util.List;

public class dihanDuck implements Quackable{

    List<Observer>observers = new ArrayList<>();
    @Override
    public void quack() {
        System.out.println("Dihan quacks");
    }


    }

