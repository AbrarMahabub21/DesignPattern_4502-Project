package Project;

public class Goose {
    public void honk(){
        System.out.println("Goose honks");
    }
}
