package Project;

import java.util.ArrayList;
import java.util.List;

public class wonderDuck implements Quackable{
    List<Observer>observers = new ArrayList<>();
    @Override
    public void quack() {
        System.out.println("Wonder quacks");
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void notifyObservers() {

    }
}
