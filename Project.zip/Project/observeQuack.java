package Project;

public interface observeQuack {
    void registerObserver( Observer observer);
    void notifyObservers();
}
