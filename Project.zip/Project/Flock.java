package Project;
import java.util.*;

public class Flock implements Quackable,observeQuack{
    List<Quackable>ducks = new ArrayList<>();
    private List<Observer> observers = new ArrayList<>();
    public void add(Quackable duck){
        ducks.add(duck);
    }
    @Override
    public void quack() {
        for (Quackable duck: ducks){
            duck.quack();
        }
        notifyObservers();
    }
    public Iterator<Quackable> iterator() {
        return ducks.iterator();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }
}
