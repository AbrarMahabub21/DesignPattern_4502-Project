package Project;

public class quackologist implements Observer{
    @Override
    public void update(observeQuack duck) {
        System.out.println("Quackologist: just quacked.");
    }
}
