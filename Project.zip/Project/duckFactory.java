package Project;

public class duckFactory {
    public Quackable createDihanDuck(){
        return new dihanDuck();
    }

    public Quackable createWonderDuck(){
        return new wonderDuck();
    }
}
