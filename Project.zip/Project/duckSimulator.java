package Project;

public class duckSimulator {
        public static void main(String[] args) {
            // Step 1: Create Duck Factory
            duckFactory duckFactory = new duckFactory();
            countingDuckFactory countingDuckFactory = new countingDuckFactory();

            // Step 2: Create Ducks
            Quackable dihanDuck =  duckFactory.createDihanDuck();
            Quackable wonderDuck = duckFactory.createWonderDuck();

            Quackable countingDihandDuck = countingDuckFactory.createDihanDuck();
            Quackable countingWonderDuck = countingDuckFactory.createWonderDuck();

            // Step 3: Create Flock
            Flock flock = new Flock();
            flock.add(dihanDuck);
            flock.add(wonderDuck);
            flock.add(new gooseAdapter(new Goose())); // Adapt a Goose to a Duck

            // Step 4: Register Observer for Real-Time Quack Tracking
            quackologist quackologist = new quackologist();
            flock.registerObserver(quackologist);
            countingDihandDuck.registerObserver(quackologist);

            // Step 5: Simulate Quacks
            simulateQuacks(flock); // Simulate quacks for the entire flock
            simulateQuacks(countingDuckFactory.createDihanDuck()); // Simulate quacks for a specific duck

            // Step 6: Display Total Quack Count
            System.out.println("Total Quacks: " + quackCounter.getCounter());
        }

        private static void simulateQuacks(Quackable duck) {
            duck.quack();
        }
    }



