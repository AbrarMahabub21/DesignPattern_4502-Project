package Project;

import java.util.Iterator;

public class duckSimulator {
        public static void main(String[] args) {
            // Step 1: Create Duck Factory
            duckFactory duckFactory = new duckFactory();
            countingDuckFactory countingDuckFactory = new countingDuckFactory();

            // Step 2: Create Ducks
            Quackable dihanDuck =  duckFactory.createDihanDuck();
            Quackable wonderDuck = duckFactory.createWonderDuck();
            Quackable gooseAdapter = new gooseAdapter(new Goose());

            duckFactory DuckFactory = new duckFactory();
            countingDuckFactory CountingDuckFactory = new countingDuckFactory();

            Quackable countDihandDuck = countingDuckFactory.createDihanDuck();
            Quackable countWonderDuck = countingDuckFactory.createWonderDuck();

            // Step 3: Create Flock
            Flock flock = new Flock();
            flock.add(dihanDuck);
            flock.add(wonderDuck);
            flock.add(gooseAdapter); // Adapt a Goose to a Duck

            Flock flockOfCountedDucks = new Flock();
            flockOfCountedDucks.add(countDihandDuck);
            flockOfCountedDucks.add(countWonderDuck);

            flock.add(flockOfCountedDucks);

            // Step 4: Register Observer for Real-Time Quack Tracking
            quackologist quackologist = new quackologist();
            flock.registerObserver(quackologist);

            // Step 5: Simulate Quacks
            simulateQuacks(flock); // Simulate quacks for the entire flock


            // Step 6: Display Total Quack Count
            System.out.println("Total Quacks: " + quackCounter.getCounter());
        }

    private static void simulateQuacks(Quackable duck) {
        duck.quack();

        if (duck instanceof Flock) {
            Iterator<Quackable> iterator = ((Flock) duck).iterator();
            while (iterator.hasNext()) {
                simulateQuacks(iterator.next());
            }
        }
    }
    }



