package Project;

public interface Quackable {
    public void quack();
}
