package Project;

import java.util.ArrayList;
import java.util.List;

public class quackCounter implements Quackable,observeQuack {
    Quackable duck;
    static int cnt = 0;
    private List<Observer> observers = new ArrayList<>();
    public quackCounter (Quackable duck){
        this.duck = duck;
    }


    @Override
    public void quack() {
        duck.quack();
        cnt++;
        notifyObservers();
    }

    public static int getCounter(){
        return cnt;
    }


    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }

    }

